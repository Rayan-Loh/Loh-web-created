<?php
require '_base.php';

include '_head.php';
?>
    <nav>
        <div class="First-Box-Container">
            <div class="轮播">
                <img src="image/fashion1.jpg" alt="">
            </div>
        </div>
    </nav>

<?php
include '_foot.php';
?>
   