<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ROXY'S Online Shopping</title>
    <link rel="shortcut icon" href="image\1740232192815.png" type="image/x-icon">
    <link rel="stylesheet" href="/css/home_style.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> 
    <!--script src="/js/app.js"></script-->
</head>
<main> 
<body>
    <header>
        <div class="ROXYS">
            <img src="image\1740232192815.png">
            <p style="font-family: 'Custom1';">ROXY'S</p>
        </div>

        <div class="search-container">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Search" class="search-bar">
        </div>

        <div class="right-icon">
            <div class="icon-container">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="icon-container">
                <i class="fas fa-user"></i>
            </div>
        </div>
    </header>